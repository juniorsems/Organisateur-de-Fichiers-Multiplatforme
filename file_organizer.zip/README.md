# Organisateur de Fichiers Automatique (C/SDL)

## Introduction

Ce projet est un utilitaire multiplateforme développé en **C** avec la bibliothèque **SDL2** pour l'interface graphique et **Native File Dialog Extended (NFDe)** pour la sélection de dossiers. Son objectif est de simplifier l'organisation des dossiers encombrés (comme le dossier "Téléchargements") en déplaçant automatiquement les fichiers dans des sous-dossiers catégorisés selon leur extension.

L'application est conçue pour être portable et utilisable sur les systèmes d'exploitation **Windows**, **Linux** et **macOS**.

## Fonctionnalités

*   **Interface Graphique Simple** : Utilisation de SDL2 pour une interface utilisateur minimaliste et fonctionnelle.
*   **Sélection de Dossier Native** : Utilisation de NFDe pour afficher la boîte de dialogue de sélection de dossier native du système d'exploitation.
*   **Organisation Automatique** : Scan du dossier sélectionné et déplacement des fichiers dans des sous-dossiers basés sur une table de correspondance d'extensions.
*   **Multiplateforme** : Code C standard et utilisation de bibliothèques portables (SDL2, NFDe, TinyDir, cwalk).

## Catégories d'Organisation

Les fichiers sont déplacés dans les sous-dossiers suivants :

| Catégorie | Sous-dossier | Extensions prises en charge |
| :--- | :--- | :--- |
| **Documents** | `Documents` | `.pdf`, `.docx`, `.txt`, `.xlsx`, `.pptx` |
| **Images** | `Images` | `.jpg`, `.jpeg`, `.png`, `.gif`, `.bmp` |
| **Vidéos** | `Videos` | `.mp4`, `.mkv`, `.avi`, `.mov` |
| **Musique** | `Music` | `.mp3`, `.wav`, `.flac` |
| **Archives** | `Archives` | `.zip`, `.tar`, `.gz`, `.rar`, `.7z` |
| **Autres** | `Autres` | Toutes les autres extensions non listées |

## Compilation (Utilisation de CMake)

Le projet utilise **CMake** pour gérer la compilation sur différentes plateformes.

### Prérequis

Vous devez avoir installé :
1.  Un compilateur C (GCC, Clang, MSVC).
2.  **CMake** (version 3.10 ou supérieure).
3.  Les bibliothèques de développement **SDL2** et **GTK3** (pour Linux).

### Étapes de Compilation

```bash
# 1. Cloner le dépôt (ou décompresser l'archive)
# git clone <URL_DU_DEPOT>
cd file_organizer

# 2. Créer un dossier de build
mkdir build
cd build

# 3. Configurer le projet avec CMake
# Sur Linux/macOS, cela trouvera SDL2 et GTK3 (pour NFDe)
cmake ..

# 4. Compiler l'exécutable
make
```

L'exécutable `FileOrganizer` sera généré dans le dossier `build`.

## Architecture du Code

Le projet est structuré autour de trois composants principaux :

1.  **`src/main.c`** : Contient la boucle principale SDL, l'initialisation de l'interface et la gestion des événements (clic sur le bouton). Il utilise NFDe pour la boîte de dialogue de sélection.
2.  **`src/organizer.c`** : Contient la logique métier. Il utilise **TinyDir** pour parcourir le dossier et **cwalk** pour extraire les extensions de fichiers. La fonction `organize_directory` effectue le déplacement des fichiers.
3.  **`external/`** : Contient les en-têtes et sources des bibliothèques tierces (TinyDir, cwalk, et le code source de NFDe).

## Bibliothèques Tierces

| Bibliothèque | Rôle |
| :--- | :--- |
| **SDL2** | Interface graphique et gestion des événements. |
| **Native File Dialog Extended (NFDe)** | Boîte de dialogue native de sélection de dossier. |
| **TinyDir** | Parcours de dossiers multiplateforme en C. |
| **cwalk** | Manipulation de chemins de fichiers (extraction d'extension). |

---
*Projet développé par Manus AI.*
