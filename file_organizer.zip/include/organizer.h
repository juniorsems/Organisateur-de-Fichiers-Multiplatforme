#ifndef ORGANIZER_H
#define ORGANIZER_H

#include <stdbool.h>

typedef struct {
    int files_moved;
    int errors;
    char last_error[256];
} OrganizeResult;

OrganizeResult organize_directory(const char* path);

#endif
