#include "organizer.h"
#include "../external/tinydir.h"
#include "../external/cwalk.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <errno.h>

#ifdef _WIN32
#include <direct.h>
#define mkdir(path, mode) _mkdir(path)
#else
#include <unistd.h>
#endif

typedef struct {
    const char* extension;
    const char* category;
} ExtensionMap;

static ExtensionMap extension_map[] = {
    {".pdf", "Documents"}, {".docx", "Documents"}, {".txt", "Documents"}, {".xlsx", "Documents"}, {".pptx", "Documents"},
    {".jpg", "Images"}, {".jpeg", "Images"}, {".png", "Images"}, {".gif", "Images"}, {".bmp", "Images"},
    {".mp4", "Videos"}, {".mkv", "Videos"}, {".avi", "Videos"}, {".mov", "Videos"},
    {".mp3", "Music"}, {".wav", "Music"}, {".flac", "Music"},
    {".zip", "Archives"}, {".tar", "Archives"}, {".gz", "Archives"}, {".rar", "Archives"}, {".7z", "Archives"},
    {NULL, NULL}
};

const char* get_category(const char* ext) {
    for (int i = 0; extension_map[i].extension != NULL; i++) {
        if (strcasecmp(ext, extension_map[i].extension) == 0) {
            return extension_map[i].category;
        }
    }
    return "Autres";
}

OrganizeResult organize_directory(const char* path) {
    OrganizeResult result = {0, 0, ""};
    tinydir_dir dir;

    if (tinydir_open(&dir, path) == -1) {
        result.errors++;
        snprintf(result.last_error, sizeof(result.last_error), "Impossible d'ouvrir le dossier: %s", path);
        return result;
    }

    while (dir.has_next) {
        tinydir_file file;
        tinydir_readfile(&dir, &file);

        if (!file.is_dir && file.name[0] != '.') {
            const char* ext;
            cwk_path_get_extension(file.name, &ext, NULL);

            if (ext != NULL) {
                const char* category = get_category(ext);
                char dest_dir[1024];
                char dest_path[1024];

                snprintf(dest_dir, sizeof(dest_dir), "%s/%s", path, category);
                
                // Créer le dossier s'il n'existe pas
                mkdir(dest_dir, 0755);

                snprintf(dest_path, sizeof(dest_path), "%s/%s", dest_dir, file.name);

                if (rename(file.path, dest_path) == 0) {
                    result.files_moved++;
                } else {
                    result.errors++;
                    snprintf(result.last_error, sizeof(result.last_error), "Erreur lors du déplacement de %s", file.name);
                }
            }
        }

        tinydir_next(&dir);
    }

    tinydir_close(&dir);
    return result;
}
