#include <SDL2/SDL.h>
#include <nfd.h>
#include <stdio.h>
#include <stdbool.h>
#include "organizer.h"

const int SCREEN_WIDTH = 640;
const int SCREEN_HEIGHT = 480;

void draw_text_placeholder(SDL_Renderer* renderer, const char* text, int x, int y) {
    // Note: Pour un vrai projet, on utiliserait SDL_ttf. 
    // Ici, on simule l'interface pour la démonstration.
    SDL_Rect rect = {x, y, 200, 40};
    SDL_SetRenderDrawColor(renderer, 200, 200, 200, 255);
    SDL_RenderFillRect(renderer, &rect);
}

int main(int argc, char* args[]) {
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        printf("SDL could not initialize! SDL_Error: %s\n", SDL_GetError());
        return 1;
    }

    if (NFD_Init() != NFD_OKAY) {
        printf("NFD could not initialize!\n");
        return 1;
    }

    SDL_Window* window = SDL_CreateWindow("Organisateur de Fichiers Automatique", 
        SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);
    
    if (window == NULL) {
        printf("Window could not be created! SDL_Error: %s\n", SDL_GetError());
        return 1;
    }

    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    
    bool quit = false;
    SDL_Event e;
    char status_msg[256] = "Prêt. Cliquez pour choisir un dossier.";

    while (!quit) {
        while (SDL_PollEvent(&e) != 0) {
            if (e.type == SDL_QUIT) {
                quit = true;
            } else if (e.type == SDL_MOUSEBUTTONDOWN) {
                nfdchar_t *outPath = NULL;
                nfdresult_t result = NFD_PickFolder(&outPath, NULL);

                if (result == NFD_OKAY) {
                    snprintf(status_msg, sizeof(status_msg), "Organisation de : %s...", outPath);
                    
                    OrganizeResult res = organize_directory(outPath);
                    
                    snprintf(status_msg, sizeof(status_msg), "Terminé ! %d fichiers déplacés. %d erreurs.", 
                             res.files_moved, res.errors);
                    
                    NFD_FreePath(outPath);
                } else if (result == NFD_CANCEL) {
                    snprintf(status_msg, sizeof(status_msg), "Annulé par l'utilisateur.");
                } else {
                    snprintf(status_msg, sizeof(status_msg), "Erreur : %s", NFD_GetError());
                }
            }
        }

        SDL_SetRenderDrawColor(renderer, 45, 45, 45, 255);
        SDL_RenderClear(renderer);

        // Dessiner un "bouton" central
        SDL_Rect button = { SCREEN_WIDTH/2 - 150, SCREEN_HEIGHT/2 - 50, 300, 100 };
        SDL_SetRenderDrawColor(renderer, 0, 120, 215, 255);
        SDL_RenderFillRect(renderer, &button);

        // Affichage console du statut (car SDL_ttf demande des fichiers de police)
        static char last_printed[256] = "";
        if (strcmp(last_printed, status_msg) != 0) {
            printf("Statut: %s\n", status_msg);
            strcpy(last_printed, status_msg);
        }

        SDL_RenderPresent(renderer);
    }

    NFD_Quit();
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}
